 
 Linter & Formatter
 why we need linting or formatting?
    when working with team, everyone should follow same indentation for consistency is formatting
    uses better syntexes and consistency with best practices
setup biom for both formatting and linting

Oauth
   1. google auth library
   2. client id
   3. google cloud platform (GCP) -> generate client id
Validation and sanitization
   1. install zod
   2. create zod schema
   3. create higherOrder function middleware to validate request
Forgot password: 
   1. create redis server for otp store
   2. connect to redis 
   3. generate random otp
   4. set redis after forgot pass
   5. reset otp
Send OTP to gmail
   1. Gmail, nodemailer
   2. gmail/ google app password
   3. nodemailer config
Email verification
   1. create otp and user data store in redis
   2. send email with otp using ejs
   3. registration process with email
      1. register api => user data => pass hash => user data => redis => otp => redis => otp email
      2. otp verify => otp verified =>  redis user data => actual db store => auto logi by cookie set
      3. redis data => parse
image upload using multer and cloudinary for profile image
   1. multer => middleware => form data hadle => file handle
   2. multer setup => storage => multer memory storatge(ram)
   3. upload => upload.single(fileName) upload.array
   4. cloudinary configuration, cloud name, api key, api secret
   5. cloudinary built in function upload_stream(Buffer)
   6. upload_stream => callback pattern promise handle => async await and promnise
   7. secure url, public id => db store
   8. previous image delete from cloudinary